Server is same as Assignment 2B.

Client is based off of https://github.com/juleswhite/mobilecloud-15/tree/master/ex/VideoUploadClient(Secured)/src/vandy/mooc

Server and Client are individual applications, need to be imported as seperate projects.

Import Server into Android Studio, start by running Application.

Build Client and run on emulator. Server data for client is https://10.0.2.2:8443, users are
admin:pass
user0:pass

And all of that you set in settings.

To upload metadata, click on button, and browse to video who's metadata you want to upload. Once metadata is uploaded, click on video metadata to like/unlike.